export { default as withWalletConnect } from "./withWalletConnect";
